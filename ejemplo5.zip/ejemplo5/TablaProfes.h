#ifndef TABLAPROFES_H
#define TABLAPROFES_H

#include <QWidget>
#include<vector>
#include<string>

using namespace std;

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:
    void on_agregar_clicked();

    void readCSV(istream &input, vector< vector<string> > &output);

    void initData(vector< vector<string> > &datos);

    void saveData(vector< vector<string> > &output);

private:
    Ui::Widget *ui;
    typedef vector< vector<string> > csvVector;
    csvVector csvData;
};

#endif // TABLAPROFES_H

