#include "addprofe.h"
#include "ui_addprofe.h"

AddProfe::AddProfe(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddProfe)
{
    ui->setupUi(this);
}

AddProfe::~AddProfe()
{
    delete ui;
}

void AddProfe::on_respuesta_accepted()
{
    accept();
}

void AddProfe::on_respuesta_rejected()
{
    reject();
}

QString AddProfe::get_nombre()
{
    return ui->nombre->text();
}

int AddProfe::get_edad()
{
    return ui->edad->value();
}

double AddProfe::get_puntaje()
{
    return ui->puntaje->value();
}

QString AddProfe::get_materia()
{
    return ui->materia->currentText();
}

QString AddProfe::get_nivel()
{
    return ui->nivel->currentText();
}

QString AddProfe::get_contrato()
{
    if(ui->radio1->isChecked())
        return((QString)"Permanente");
    else if(ui->radio2->isChecked())
        return((QString)"Ocasional");
    else if(ui->radio3->isChecked())
        return((QString)"Catedra");
    else
        return((QString)"Desconocido");

}
