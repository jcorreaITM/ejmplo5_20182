#ifndef ADDPROFE_H
#define ADDPROFE_H

#include <QDialog>

namespace Ui {
class AddProfe;
}

class AddProfe : public QDialog
{
    Q_OBJECT

public:
    explicit AddProfe(QWidget *parent = 0);
    ~AddProfe();

    QString get_nombre();

    int get_edad();

    double get_puntaje();

    QString get_materia();

    QString get_nivel();

    QString get_contrato();

private slots:
    void on_respuesta_accepted();

    void on_respuesta_rejected();

private:
    Ui::AddProfe *ui;

};

#endif // ADDPROFE_H
