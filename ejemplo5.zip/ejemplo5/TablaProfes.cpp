#include "TablaProfes.h"
#include "ui_widget.h"
#include "addprofe.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    setWindowTitle("Profesores");  //Dandole nombre a ventana de la tabla
    QStringList columnas; //Defina una lista para los nombres de las columnas
    columnas<<"Nombre"<<"Materia"<<"Nivel"<<"Edad"<<"Puntaje"<<"Contrato"; //Agregue los nombres a la lista
    ui->tabla->setColumnCount(6); //Defina el numero de columnas de la tabla
    ui->tabla->setHorizontalHeaderLabels(columnas); //Asigne los nombres de la lista a la tabla

    fstream file("C:/Users/juancorrea/Documents/Cursos/2018_2/Lenguages_de_Prog/Electronica/labqt1/ejemplo5_20182/ejemplo5/datos.csv", ios::in);
    if(!file.is_open())
    {
           cout << "File not found, table empty!\n";
            //return 1;
    }
    // typedef to save typing for the following object
    readCSV(file, csvData);
    initData(csvData);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::readCSV(istream &input, vector< vector<string> > &output)
{
   string csvLine;

    // read every line from the stream
    while( getline(input, csvLine) )
    {

        istringstream csvStream(csvLine);
        vector<string> csvColumn;
        string csvElement;
        // read every element from the line that is seperated by commas
        // and put it into the vector or strings
        while( getline(csvStream, csvElement, ',') )
        {
            csvColumn.push_back(csvElement);
            //cout<<csvElement<<endl;
        }
        output.push_back(csvColumn);
    }
}

void Widget::initData(csvVector &datos)
{
    int fila = 0;

    for(int i = 0; i<datos.size(); ++i)
    {
        ui->tabla->insertRow(ui->tabla->rowCount()); //Inserte una fila en la tabla
        fila = ui->tabla->rowCount()-1; //Identifique la fila en la que va escribiendo la tabla
        for(int j = 0; j<datos[i].size(); ++j)
        {
            //cout<<datos[i][j];
            ui->tabla->setItem(fila, j, new QTableWidgetItem(QString::fromStdString(datos[i][j])));
        }

        //cout << "\n";
    }
}

void Widget::saveData(vector< vector<string> > &output)
{
    ofstream myfile;
    string a;

    myfile.open("C:/Users/juancorrea/Documents/Cursos/2018_2/Lenguages_de_Prog/Electronica/labqt1/ejemplo5_20182/ejemplo5/datos.csv");

    for(csvVector::iterator i = output.begin(); i != output.end(); ++i)
    {
        for(vector<string>::iterator j = i->begin(); j != i->end(); ++j)
        {
            a=*j;
            cout << a << " ";
            myfile <<a;
            if(j != (i->end())-1)
                myfile<<",";
        }
        myfile <<"\n";
        cout << "\n";
    }
    myfile.close();

}

void Widget::on_agregar_clicked()
{
    int res = 0;   //Variables locales para almacenar datos
    int fila = 0;
    int edad = 0;
    double puntaje;
    QString nombre;
    QString nivel;
    QString materia;
    QString contrato;

    AddProfe obj(this); //Declarando un objeto de la clase del Dialogo (AddProfe)
    obj.setWindowTitle("Agregar Datos Profesor"); //Dandole un nombre a la ventana del dialogo
    res = obj.exec(); //Ejecutando el objeto del dialogo para que se muestre en pantalla

    if(res==QDialog::Rejected) //Si dan click en "Cancelar" en el dialogo regrese a la tabla (widget)
        return;

    nombre = obj.get_nombre();  //Si dieron click en "Ok" entonces colecte en las variables locales
    materia = obj.get_materia(); // los valores que haya en los elementos graficos
    nivel = obj.get_nivel();
    edad = obj.get_edad();
    puntaje = obj.get_puntaje();
    contrato = obj.get_contrato();

    ui->tabla->insertRow(ui->tabla->rowCount()); //Inserte una fila en la tabla
    fila = ui->tabla->rowCount()-1; //Identifique la fila en la que va escribiendo la tabla
    ui->tabla->setItem(fila, 0, new QTableWidgetItem(nombre)); //Escriba los datos capturados en el dialogo
    ui->tabla->setItem(fila, 1, new QTableWidgetItem(materia));//en las columnas de la tabla
    ui->tabla->setItem(fila, 2, new QTableWidgetItem(nivel));  //columnas de la 0 a la 5 (6 columnas)
    ui->tabla->setItem(fila, 3, new QTableWidgetItem(QString::number(edad)));
    ui->tabla->setItem(fila, 4, new QTableWidgetItem(QString::number(puntaje)));
    ui->tabla->setItem(fila, 5, new QTableWidgetItem(contrato));

    vector<string> new_data;
    new_data.push_back(nombre.toStdString());
    new_data.push_back(materia.toStdString());
    new_data.push_back(nivel.toStdString());
    new_data.push_back(QString::number(edad).toStdString());
    new_data.push_back(QString::number(puntaje).toStdString());
    new_data.push_back(contrato.toStdString());

    csvData.push_back(new_data);
    saveData(csvData);

}








